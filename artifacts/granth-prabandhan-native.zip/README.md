# ग्रंथ प्रबंधन — native Android app

React Native + TypeScript app for the Granth Prabandhan catalog. The interface is native views (`View`, `Text`, `Image`, `FlatList`, `Pressable`). It does **not** use `react-native-webview` and it does not load granth.wnmsolutions.com as the UI.

This folder is an Expo SDK 57 project. An APK/AAB is produced by Android Studio or EAS Build. This repository does not contain a prebuilt APK.

## What you can do

- Dashboard, Topics, Granths, Pramans
- Granth columns: 1×1, 2×2, 3×3 (`FlatList` `numColumns`, saved on device)
- Pramaan columns: 1×1, 2×2
- Gallery columns: 1×1, 2×2
- First online open stores topics, granths, and pramans in SQLite, then downloads images into app storage and skips files that already exist
- Offline search: Hindi matras, Hinglish (`mans` → मांस, `geeta`, `krishna`, `kabir`, `brahm`, `mrityu`), fuzzy edit distance, and multi-word relevance (`ब्रह्मा की मृत्यु`)
- Round download button on every image. The full file is saved in the phone album **ग्रंथ प्रबंधन** (Android MediaStore via `expo-media-library`) and in the in-app gallery with title, text, topic, granth, and date
- PDF of a card includes the image, title, body, and metadata (Noto Sans Devanagari). PDFs can also be written with the Storage Access Framework
- Gallery folders: create, rename (long-press), delete, move, share, delete
- Download queue: progress, pause, resume, retry, cancel, duplicate skip, image magic-byte check
- Resource packs: JSON or zip containing `resourceVersion`, `topics`, `granths`, `pramans`. Default version is `1.0.0`

## Scripts

```bash
npm install
npm run typecheck
npm run test:search
npm start
```

Android device or emulator (Android Studio, SDK installed):

```bash
npx expo prebuild --platform android
npx expo run:android
```

Release APK from the generated project:

```bash
cd android
./gradlew assembleRelease
```

The APK is `android/app/build/outputs/apk/release/app-release.apk`. A signed Play bundle:

```bash
cd android && ./gradlew bundleRelease
```

Cloud build without a local SDK:

```bash
npx eas build -p android --profile preview
```

## Search check

`npm run test:search` asserts `mans` finds “मांस खाने वाले को नरक मिलता है”, plus geeta, kabeer, mrityu, brahm, krishna, and the phrase “ब्रह्मा की मृत्यु”.

## Permissions

Images use the photo library (MediaStore). PDFs use the system folder picker (Storage Access Framework) the first time, then the chosen directory is remembered. The app does not request broad legacy external storage beyond what `expo-media-library` adds for Android 9 compatibility.
